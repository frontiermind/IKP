jQuery(function($){

	/**
	 * スクロール
	 */
	$('a[href^="#"]').click(function() {
		var target = $($(this).attr('href'));
		if (target.length) {
			var targetPosition = target.offset();
			$('body, html').animate({
				scrollTop: targetPosition.top + 'px'
			}, 1000);
      $('#js-menu-button').removeClass('is-active');
      $('#js-global-nav').slideUp();
			return false;
		}
	});
});
