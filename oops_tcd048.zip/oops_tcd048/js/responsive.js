jQuery(function($){

	/**
	 * グローバルナビゲーション
	 */
	$('#js-menu-button').click(function() {
		$(this).toggleClass('is-active');
		$('#js-global-nav').slideToggle();		
		return false;
	});
	$('.menu-item-has-children > a span').click(function() {
		$(this).toggleClass('is-active').closest('.menu-item-has-children').toggleClass('is-active');
		$(this).parent('a').next('.sub-menu').slideToggle();
		return false;
	});

function mediaQueryClass(width) {
 if (width > 1200) { //PC
   $(".p-global-nav .sub-menu").css("display","block");
 } else { //smart phone
   $(".p-global-nav .menu-item-has-children").removeClass("is-active")
   $(".menu-item-has-children > a span").removeClass("is-active")
   $(".p-global-nav .sub-menu").css("display","none");
 }
};

function viewport() {
    var e = window, a = 'inner';
    if (!('innerWidth' in window )) {
        a = 'client';
        e = document.documentElement || document.body;
    }
    return { width : e[ a+'Width' ] , height : e[ a+'Height' ] };
}

var ww = viewport().width;

mediaQueryClass(ww);

$(window).bind("resize orientationchange", function() {
  var ww = viewport().width;
  mediaQueryClass(ww);
})

});	
